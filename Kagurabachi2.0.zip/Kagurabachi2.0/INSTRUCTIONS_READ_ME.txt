hey 
to install kagurabchi mc

unzip the folder

first you need to install optifine and the damage command mod (mc version 1.19.2)
https://www.curseforge.com/minecraft/mc-mods/damage-command-with-damage-types 
https://optifine.net/downloads
copy these into a search engine

then go into a 1.19.2 world 

get a structure block using /give @s structure_block

find your world in file exsplorer

go into the file and place the "generated file" into it 

go back into your world and use the structure block to load "kagurabachi2.0" and "magatsumi" 

then press all the buttons next to the yellow glass (not the start area)

read the book in the chest at the starting area